   <!DOCTYPE html>
<html lang="en">
  <head>
   
    <title>Admin Area | Dashboard</title>
    <!-- Bootstrap core CSS -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" >
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" >
  
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
  </head>
  <body>
  
            <!-- Website Overview -->
            
                <table id="example" class="display" style="width:100%">
                      <tr>
                        <th>Category Id</th>
                        <th>Name</th>
                       <th>Created-At</th>
                       <th>Action</th>
                      </tr>
                    <tbody id="tdata"></tbody>
                        
                    </table>
            
           

         
           <footer class="footer-48201" id="footerr">
      
      <div class="container">
        <div class="row">
      
          
          <div class="col-md-12">
             <form id="edit_category">
      <div class="modal-header">
        
        <h4 class="modal-title" id="myModalLabel">Edit Category</h4>
      </div>
      <div class="modal-body">
       <input type ="hidden" id="cat_id" name ="id">
        <div class="form-group">
          <label>Edit Category Title</label>
          <input type="text" name="title" id="titles" class="form-control" placeholder="Page Title">
        </div>
  
      </div>
      <div class="modal-footer">
       
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
          </div>
         
        </div> 

       
      </div>
      
    </footer>

<script src="vendor/jquery/jquery-3.6.0.min.js"></script>

          <script type="text/javascript">
           
                         $(document).ready(function(){
           
 $('#tdata').on('click','.btn-edit', function(){
          var id=$(this).parents('tr').attr('data-id');
                 var name=$(this).parents('tr').attr('data-name');
$('#titles').val($(this).parents('tr').attr('data-name'));
$('#cat_id').val($(this).parents('tr').attr('data-id'));
           

            });
 $('#tdata').on('click','.btn-delete', function(){
          var id=$(this).parents('tr').attr('data-id');
             
    
    $.ajax({
                url: "http://localhost/restapi_example/category.php?id="+id,
                method: "DELETE",
                dataType: "JSON",
                
                success: function (response) {
                    console.log(response);
    
                    
                }
             

      });
               // $('#category_id').val($(this).data('id'));
               // $('#edit_name').val($(this).html());

            });
$('#edit_category').on("submit", function(event){
          event.preventDefault();

   var id = $('#cat_id').val();
    var name = $('#titles').val();
  
    
    
    $.ajax({
    
    url: "http://localhost/restapi_example/category.php?id="+id+"&name="+name,
                method: "PUT",
                dataType: "JSON",
        success: function (response) {
                    console.log(response);
          }
    
    
      });
    
    });
            $.ajax({
                url: "http://localhost/Application/restapi_example/category.php",
                method: "GET",
                dataType: 'JSON',
                cache: false,
                success: function (response) {
                       console.log(response);

                  
              response.forEach(function(row){
                     $('#tdata').append(
"<tr data-id='"+row.Id+"' data-name='"+row.name+"' ><td>"+row.Id+"</td><td>"+row.name+"</td><td>"+row.created_at+"</td><td><button class='btn btn-danger btn-lg btn-delete mr-3' type='button'>Delete</button><button  class='btn btn-info btn-lg btn-edit btn-edit' type='submit'>Edit</button></td></tr>"

                     
                       );

                       });
                                 
              },

               
                error: function(response) {
   alert(response);
                }
            });
});
    </script>
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($){
  $('#example').DataTable({
    language: {
      lengthMenu: "T'en veux _MENU_ par page",
      info: "T'es bigleux ? c'est la page _PAGE_ sur _PAGES_",
      search: "Cherche bouffon !",
      paginate: {
        first:      "Premier",
        last:       "Précédent",
        next:       "Suivant",
        previous:   "Dernier"
      }
    }
  });
});
  </script>
  </body>

</html>