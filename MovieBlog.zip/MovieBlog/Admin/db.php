<?php 
	
	session_start();
	
	$conn = new mysqli('localhost','root','','application');
	
	if($conn->connect_error) {
		die("DB Connection Error");
	}
	
?>