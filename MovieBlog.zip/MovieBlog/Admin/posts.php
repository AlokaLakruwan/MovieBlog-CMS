<!DOCTYPE html>
<html lang="en">

<head>
   <title>Admin Area | Dashboard</title>
   <!-- Bootstrap core CSS -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <link href="css/style.css" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.0/css/jquery.dataTables.css">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
</head>

<body>
   <div id="postsss">
      <!-- Website Overview -->
      <div class="panel panel-default">
         <div class="panel-heading main-color-bg">
            <h3 class="panel-title" id="pp">Posts</h3>
         </div>
         <div class="panel-body">
            <br>
            <!-- <table class="display table table-striped table-hover" id="example" border="2">
               <thead>
                  <tr>
                     <th>Title</th>
                     <th colspan="2">Content</th>
                     <th>CategoryId</th>
                     <th>Image</th>
                     <th>Action</th>
                  </tr>
               </thead>
               <tbody id="tdata">
                  <tr>
                     <td>Row 1 Data 1</td>
                     <td>Row 1 Data 2</td>
                  </tr>
               </tbody>
            </table> -->

            <table id="table_id" class="display">
               <thead>
                  <tr>
                     <th>Title</th>
                     <th>Content</th>
                     <th>CategoryId</th>
                     <th>Image</th>
                     <th>Action</th>
                     <th>Action</th>
                  </tr>
               </thead>
               <tbody>
                  
               </tbody>
            </table>
         </div>
      </div>
   </div>
   <footer class="footer-48201" id="footerr">
      <div class="container">
         <div class="row">
            <div class="col-md-12 ">
               <form id="edit_post">
                  <div class="modal-header">
                     <h4 class="modal-title" id="myModalLabel">Edit Post</h4>
                  </div>
                  <div class="modal-body">
                     <div class="row">
                        <input type="hidden" id="post_id" name="post_id">
                        <div class="form-group col-md-6">
                           <label>Edit Title</label>
                           <input type="text" name="edittitle" id="edittitle" class="form-control" placeholder="Post Title" required>
                        </div>
                        <div class="form-group col-md-6">
                           <label>Change Category Id</label>
                        
                           <select name="editcategory_id" id="editcategory_id" class="form-control" required>

                           </select>
                        </div>
                       
                     </div>
                     <div class="form-group">
                        <label>Edit Content</label>
                        <textarea name="editcontent" id="editcontent" class="form-control" placeholder="Post Content" required></textarea>
                     </div>
                  </div>
                  <div class="modal-footer">
                     <button type="submit" class="btn btn-primary">Save Changes</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </footer>
   <script src="vendor/jquery/jquery-3.6.0.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js" ></script>
   <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.js"></script>
   <script type="text/javascript" src="https://editor.datatables.net/extensions/Editor/js/dataTables.editor.min.js"></script>
   <script type="text/javascript">
      $(document).ready(function() {

      var table = $('#table_id').DataTable( {
         'ajax':{
            url:'../Admin/restapi/post.php',
            dataSrc:'',
         },
         "order": [[ 1, "desc" ]],
         'columns' : [
               {data:'title'},
               {data:'content'},
               {data:'category_id'},
               {data:'image'},
               {
                  data:null,
                  className: "dt-center editor-edit",
                  defaultContent: '<button type="button" on>Edit</button>',
                  orderable: false
               },
               {
                  data:null,
                  className: "dt-center editor-delete",
                  defaultContent: '<button type="button" on>Delete</button>',
                  orderable: false
               }
         ],
      });

      $('#table_id tbody').on( 'click', 'td.editor-edit', function () {
         var data = table.row( $(this).parents('tr') ).data();
         console.log(data);
         $('#post_id').val(data.id);
         $('#edittitle').val(data.title);
         $('#editcategory_id').val(data.category_id).change();
         $('#editcontent').val(data.content);
         
         table.ajax.reload();
      } );

$('#edit_post').on("submit", function(event){
          event.preventDefault();

   var id = $('#post_id').val();
    var title = $('#edittitle').val();
      var content = $('#editcontent').val();
  var category_id = $('#editcategory_id').val();


  
    $.ajax({
    
    url: "../Admin/restapi/post.php?id="+id+"&title="+title+"&content="+content+"&category_id="+category_id,
                method: "PUT",
                dataType: "JSON",
        success: function (response) {
                    console.log(response);
                     table.ajax.reload();
          }
    
    
      });
    
    });


      $.ajax({
         url: "../Admin/restapi/category.php",
         method: "GET",
         dataType: 'JSON',
         success: function(response) {
            var html = '';
            for (var i = 0; i < response.length; i++) {
               html += '<option value="' + response[i].id + '">' + response[i].name + '</option>'
            }
            $('#editcategory_id').append(html);
         }
      });


      

    

      $('#table_id tbody').on( 'click', 'td.editor-delete', function () {
         var answer=confirm("Are you sure to DLETE it?");
if (answer==true){
         var data = table.row( $(this).parents('tr') ).data();
         // console.log(data.id);
         $.ajax({
            url: "../Admin/restapi/post.php?id=" + data.id,
            method: "DELETE",
            dataType: "JSON",
            success: function(response) {
               console.log(response);
               alert(response.message);
               table.ajax.reload();
            }

         });
      }
      } );

   });
   </script>
</body>

</html>