<?php
if($_SERVER['REQUEST_METHOD'] === "GET") 
{
	session_start();
	session_unset();
	session_destroy();
	$data = array();
	$data['message'] = "User Log Out";
	$data['result'] = 'success';
	echo json_encode($data);
}

?>