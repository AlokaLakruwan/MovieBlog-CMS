 <?php 

    require "db.php";

    
     if($_SERVER['REQUEST_METHOD'] == "GET") {

        if(isset($_GET['id'])) {

            $sql = "SELECT * FROM post WHERE id=".$_GET['id'];

            $result = $conn->query($sql);

            header("HTTP/1.1 200 OK"); 
            echo json_encode($result->fetch_assoc());

        } else {

            $sql = "SELECT * FROM post";

            $result = $conn->query($sql);

            $records = [];

            while($i = $result->fetch_assoc()){
                $records[] = $i;
            }

            header("HTTP/1.1 200 OK"); 
            echo json_encode($records);

        }

    }

  if($_SERVER['REQUEST_METHOD'] === "POST") {

        // var_dump('test');
        // die();
               
        $massage = "";
        $title = $_POST['title'];
        $content = $_POST['content'];
        $image = $_FILES['image'];
        $category_id = $_POST['category_id'];

        //Get the temp file path
        $tmpFilePath = $_FILES['image']['tmp_name'];

        if ($tmpFilePath != "")
            {
                //Setup our new file path
                $newFilePath = "../uploadFiles/" . $_FILES['image']['name'];

                //Upload the file into the temp dir
                if(move_uploaded_file($tmpFilePath, $newFilePath)) {

                    $sql = "INSERT INTO post (title,content,image,category_id) VALUES ('".$title."','".$content."','".$_FILES['image']['name']."','".$category_id."')";

                    if ($conn->query($sql) === TRUE) 
                    {
                        header("HTTP/1.1 200 OK");
                        $massage =  "New record created successfully";
                    } 
                    else 
                    {
                        header("HTTP/1.1 403 ERROR"); 
                        $massage = $conn->error;
                    }
                }
            }
            echo json_encode($massage);
    }

    if($_SERVER['REQUEST_METHOD'] === "PUT") {

        if(isset($_GET['id'])) {
                
            $title = $_GET['title'];
            $content = $_GET['content'];
              
            $category_id = $_GET['category_id'];

            $sql = "UPDATE post SET title='$title',content='$content',category_id='$category_id' WHERE id=".$_GET['id'];
            
            if($conn->query($sql)) {
                header("HTTP/1.1 200 SUCCESS");
                echo json_encode(
                    array(
                        'message'=>'success'
                    )
                );
            } else {
                header("HTTP/1.1 403 ERROR");
                echo json_encode(
                    array(
                        'message'=>'error'
                    )
                ); 
            }

        }

    }

    if($_SERVER['REQUEST_METHOD'] == "DELETE") {
        if(isset($_GET['id'])) {

            $id = $_GET['id'];

            $sql = "DELETE FROM post WHERE id='$id'";

            if($conn->query($sql)) {
                header("HTTP/1.1 200 OK");
                echo json_encode(
                    array(
                        'message'=>'success'
                    )
                );
            } else {
                header("HTTP/1.1 403 ERROR");
                echo json_encode(
                    array(
                        'message'=>'error'
                    )
                );
            }
        }
    }

?>