<?php 

    require "db.php";

    
     if($_SERVER['REQUEST_METHOD'] == "GET") {

        if(isset($_GET['id'])) {

            $sql = "SELECT *,post.id as post_id FROM post INNER JOIN category ON post.category_id=category.id WHERE post.id=".$_GET['id'];

            $result = $conn->query($sql);

            header("HTTP/1.1 200 OK"); 
            echo json_encode($result->fetch_assoc());

        } else {

            $records['post'] = [];
            $records['category'] = [];

            $sql = "SELECT *,post.id as post_id FROM post INNER JOIN category ON post.category_id=category.id ORDER BY category.name ASC";

            $result = $conn->query($sql);

            while($i = $result->fetch_assoc()){
                $records['post'][] = $i;
            }

            $sql2 = "SELECT * FROM category";

            $result = $conn->query($sql2);

            while($j = $result->fetch_assoc()){
                 $records['category'][] = $j;
            }
            
            header("HTTP/1.1 200 OK"); 
            echo json_encode($records);

        }

    }