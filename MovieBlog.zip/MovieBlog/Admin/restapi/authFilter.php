<?php

if (isset($_SESSION['login'])) {
	if($_SESSION['login'] === true)
	{
		// echo 'Login';
		// header('Location: http://localhost/MovieBlog/Admin/index.php');
		// exit;
	}
	else
	{
		echo 'not Login';
		header('Location: ../Admin/index.php');
		exit;
	}
}
else
{
	echo 'not login';
	header('Location: ../Admin/index.php');
	exit;	
}

?>