<?php 

	require 'db.php';

	if($_SERVER['REQUEST_METHOD'] === "POST") 
	{
		$username = $_POST['username'];
		$password = $_POST['password'];

		$data = array();

		$sql = "SELECT password FROM admin WHERE username = '$username'";

		$result = $conn->query($sql);
		
		if ($result->num_rows > 0) 
		{
			$row = $result->fetch_assoc();
		
			if (password_verify($password, $row['password'])) 
			{	
				$sql = "SELECT * FROM admin WHERE username = '$username'";

				$result = $conn->query($sql);

				if ($result->num_rows > 0) 
				{
					$row = $result->fetch_assoc();
					$_SESSION['u_id'] = $row['id'];
					$_SESSION['u_f_name'] = $row['f_name'];
					$_SESSION['u_l_name'] = $row['l_name'];
					$_SESSION['role'] = $row['role'];
					$_SESSION['login'] = true;
				}

				$data['message'] = 'Login Success..!';
				$data['result'] = 'success';
			}
			else
			{
				$_SESSION['login'] = false;
				$data['message'] = 'Password match fail';
				$data['result'] = 'error';
			}
		}
		else
		{
			$_SESSION['login'] = false;
			$data['message'] = 'Username invalid';
			$data['result'] = 'error';
		}
		
		echo json_encode($data);
	}
?>