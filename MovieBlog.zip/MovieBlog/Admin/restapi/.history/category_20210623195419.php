<?php 

	require 'db.php';
	
	//GET - Read
	//POST - Insert
	//PUT - Update
	//DELETE - Delete
	
	if($_SERVER['REQUEST_METHOD'] === 'GET') //if the method is GET = Trying to read
	{ 
		
		if(isset($_GET['id'])) 
		{

			$sql = 'SELECT * FROM category where id='.$_GET['id'];

			$result = $conn->query($sql);

			$records = $result->fetch_assoc();

		} 
		else 
		{

			$sql = 'SELECT * FROM category'; //Query for selecting all
			
			$result = $conn->query($sql); //Executing the query
			
			$records = array();
			
			while($row = $result->fetch_assoc()) { // Loop through all records of results
				$records[] = $row; //Add row to records array
			}
		}
		
		header("HTTP/1.1 200 OK");
		echo json_encode($records); //Print records array
	}

	if($_SERVER['REQUEST_METHOD'] === 'POST') //Check the method for POST
	{
		$name = $_POST['name']; //only field that is required

		$sql = "INSERT INTO category (name) VALUES ('$name')"; //creating the SQL query

		if($conn->query($sql) === TRUE) { //if query execution is successful
			header("HTTP/1.1 200 OK"); //ALL OK
			echo json_encode(array(
				'message' => 'Success' //Success message for the client
			));
		} else {
			header("HTTP/1.1 200 ERROR");
			echo json_encode(array(
				'message' => 'Error' //Not successful. There is an error
			));
		}
	}

	if($_SERVER['REQUEST_METHOD'] === 'PUT') // See if the method is PUT
	{
		if(isset($_POST['id'])) { //See whether an ID is set to select the record

			$name = $_POST['name']; //column to update
			$id = $_POST['id']; //id to query

			$sql = "UPDATE category SET name='$name' WHERE id='$id'";

			if($conn->query($sql) === TRUE) {
				header("HTTP/1.1 200 OK"); //ALL OK
				echo json_encode(array(
					'message' => 'Success' //Success message for the client
				));
			} else {
				header("HTTP/1.1 200 ERROR"); //ALL OK
				echo json_encode(array(
					'message' => 'Error' //Success message for the client
				));
			}
		}
	}

	//example.com/categories - all records - GET
	//example.com/categories/1 - single record

	//200 - OK
	//301 - Redirecting
	//500 - Internal server error
	//403 - Forbidden 
	//404 - Page Not Found
	//503 - Service unavailable



?>