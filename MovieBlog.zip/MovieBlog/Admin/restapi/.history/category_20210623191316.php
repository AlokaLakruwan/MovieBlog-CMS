<?php 

	require 'db.php';
	
	//GET - Read
	//POST - Insert
	//PUT - Update
	//DELETE - Delete
	
	if($_SERVER['REQUEST_METHOD'] === 'GET') { //if the method is GET = Trying to read
		
		if(isset($_GET['id'])) 
		{
			$sql = 'SELECT * FROM category where id='.$id;

			$result = $conn->query($sql);

			$records = $result->fetch_assoc();
		} 
		else 
		{

			$sql = 'SELECT * FROM category'; //Query for selecting all
			
			$result = $conn->query($sql); //Executing the query
			
			$records = array();
			
			while($row = $result->fetch_assoc()) { // Loop through all records of results
				$records[] = $row; //Add row to records array
			}
		}
		
		echo json_encode($records); //Print records array
	}

	//example.com/categories - all records - GET
	//example.com/categories/1 - single record



?>