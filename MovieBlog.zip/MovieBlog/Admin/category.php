  <div id="category">
            <!-- Website Overview -->
            <div class="panel panel-default">
              <div class="panel-heading main-color-bg">
                <h3 class="panel-title">Category</h3>
              </div>
              <div class="panel-body">
               
                <br>
                <table class="table table-striped table-hover">
                      <tr>
                        <th>Category Id</th>
                        <th>Name</th>
                       
                       <th>Action</th>
                      </tr>
                    <tbody id="tdata"></tbody>
                        
                    </table>
              </div>
              </div>

          </div>
           <footer class="footer-48201" id="footerr">
      
      <div class="container">
        <div class="row">
      
          
          <div class="col-md-12">
             <form id="edit_category">
      <div class="modal-header">
        
        <h4 class="modal-title" id="myModalLabel">Edit Category</h4>
      </div>
      <div class="modal-body">
       <input type ="hidden" id="cat_id" name ="id">
        <div class="form-group">
          <label>Edit Category Title</label>
          <input type="text" name="title" id="titles" class="form-control" placeholder="Page Title">
        </div>
  
      </div>
      <div class="modal-footer">
       
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
          </div>
         
        </div> 

       
      </div>
      
    </footer>
<script src="vendor/jquery/jquery-3.6.0.min.js"></script>
           
          <script type="text/javascript">
           
                         $(document).ready(function(){
           
 $('#tdata').on('click','.btn-edit', function(){
          var id=$(this).parents('tr').attr('data-id');
                 var name=$(this).parents('tr').attr('data-name');
$('#titles').val($(this).parents('tr').attr('data-name'));
$('#cat_id').val($(this).parents('tr').attr('data-id'));
           

            });
 $('#tdata').on('click','.btn-delete', function(event){
      event.preventDefault();
var answer=confirm("Are you sure to DLETE it?");
if (answer==true){
 var id=$(this).parents('tr').attr('data-id');
             
    
    $.ajax({
                url: "../Admin/restapi/category.php?id="+id,
                method: "DELETE",
                dataType: "JSON",
                
                success: function (response) {
                    console.log(response);
     
                }
             

      });
}

      
         
               // $('#category_id').val($(this).data('id'));
               // $('#edit_name').val($(this).html());

            });
$('#edit_category').on("submit", function(event){
          event.preventDefault();

   var id = $('#cat_id').val();
    var name = $('#titles').val();
  
    
    
    $.ajax({
    
    url: "../Admin/restapi/category.php?id="+id+"&name="+name,
                method: "PUT",
                dataType: "JSON",
        success: function (response) {
                    console.log(response);
                    
          }
    
    
      });
    
    });
            $.ajax({
                url: "../Admin/restapi/category.php",
                method: "GET",
                dataType: 'JSON',
                cache: false,
                success: function (response) {
                       console.log(response);

                  
              response.forEach(function(row){
                     $('#tdata').append(
"<tr data-id='"+row.id+"' data-name='"+row.name+"' ><td>"+row.id+"</td><td>"+row.name+"</td><td><button class='btn btn-danger btn-lg btn-delete mr-3' type='button'>Delete</button><button  class='btn btn-info btn-lg btn-edit btn-edit' type='submit'>Edit</button></td></tr>"

                     
                       );

                       });
                                 
              },

               
                error: function(response) {
   alert(response);
                }
            });
});
    </script>