<?php 
   include "db.php";
   include "restapi/authFilter.php";
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Admin Area | Dashboard</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" >
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="fonts/icomoon/style.css">
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.0/css/jquery.dataTables.css">
   </head>
   <body>
      <nav class="navbar navbar-default">
         <div class="container">
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a class="navbar-brand" >AdminPanel</a>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
               <ul class="nav navbar-nav">
                  <li class="active"><a href="index.php">Dashboard</a></li>
               </ul>
               <ul class="nav navbar-nav navbar-right">
                  <li><a href="#" onclick="logOut()">Logout</a></li>
               </ul>
            </div>
            <!--/.nav-collapse -->
         </div>
      </nav>
      <header id="header">
         <div class="container">
            <div class="row">
               <div class="col-md-8">
                  <h1><span class="glyphicon glyphicon-cog rotate" aria-hidden="true"></span> Dashboard <small>Manage Your Application</small></h1>
               </div>
               <div class="col-md-4">
               <button  class="btn btn-danger mar " id="POST">Add New Post</button>
                   <button class="btn btn-danger mar "  id="CAT">Add New Category</button>
                  
                   </div>
            </div>
         </div>
      </header>
      
      <section id="main">
         <div class="container-fluid">
            <div class="row">
               <div id="pos" style="display: none;">
               <div class="col-md-12">
                  <!-- Website Overview -->
                  <div class="panel panel-default ">
                     <div class="panel-heading main-color-bg">
                        <h3 class="panel-title " id="tt">Add New Post</h3>
                     </div>
                     <div class="panel-body">
                        <form id="insert_post">
                           <div class="modal-body">
                              <div class="form-group col-md-6">
                                 <label>Post Title</label>
                                 <input type="text"  name="title" id="title" class="form-control"  placeholder="Post Title" required>
                              </div>
                              <div class="form-group col-md-6 ">
                                 <label>Category Id</label>
                                 <!-- <input type="text"  name="category_id" id="category_id" class="form-control" placeholder="Add Category Id" required> -->
                                 <select name="category_id" id="category_id" class="form-control" required>
                                    
                                 </select>
                              </div>
                              <div class="form-group col-md-6">
                                 <label>Post Content</label>
                                 <!-- <input type="text"  name="content" id="content"  class="form-control" placeholder="Post Content" required> -->
                                 <textarea name="content" id="content"  class="form-control" placeholder="Post Content" required></textarea>
                              </div>
                              <div class="form-group col-md-6">
                                 <label>Image</label>
                                 <input type="file"  name="image" id="image" class="form-control" placeholder="Add a Image" required>
                              </div>
                           </div>
                           <div class="modal-footer">
                              <button  type="submit" class="btn btn-primary">Save changes</button>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
               </div>
               <div id="cat" style="display: none;">
               <div class="col-md-12">
                  <!-- Website Overview -->
                  <div class="panel panel-default ">
                     <div class="panel-heading main-color-bg">
                        <h3 class="panel-title " id="tt">Add New Category</h3>
                     </div>
                     <div class="panel-body">
                        <form id="insert_form">
                           <div class="modal-body">
                              <div class="form-group">
                                 <label>Category Title</label>
                                 <input type="text" id="name" name="name" class="form-control" placeholder="Category Title" required>
                              </div>
                           </div>
                           <div class="modal-footer">
                              <button  type="submit" class="btn btn-primary">Save changes</button>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
               </div>
            </div>
         </div>
      </section>
      <div class="row margin">
         <div class="container">
            <div class="col-md-12 uu">
               <div class="list-group">
                  <div class="col-md-6">
                     <a  id="posts" class="list-group-item active main-color-bg">
                        <h4 class="text-center">Posts</h4>
                     </a>
                  </div>
                  <div class="col-md-6">
                     <a id="Categoriy" class="list-group-item active main-color-bg">
                        <h4 class="text-center"> Category</h4>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
            <div id="mains" class="col-md-12">
            </div>
            <div id="foot">
            </div>
         </div>
      </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js" ></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
      <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.js"></script>

      <script type="text/javascript"> 
$(document).ready(function(){
$('#POST').click(function(){
$('#pos').toggle(800);
});
$('#CAT').click(function(){
$('#cat').toggle(800);
});

});

      </script>
      <script type="text/javascript">
         $('#insert_form').on("submit",function(event) {
            event.preventDefault();
            $.ajax({
      
                   url: "restapi/category.php",
                   method: "POST",
                   dataType: "JSON",
                   data: $('#insert_form').serialize(),
                   success: function(response) {
                       console.log(response);
                      table.ajax.reload();
                   }
            });
         });

         $('#insert_post').on("submit",function(event) {
            event.preventDefault();
            $.ajax({
               url: "../Admin/restapi/post.php",
               method: "POST",
               dataType: "JSON",
               contentType: false,
               processData: false,
               enctype: 'multipart/form-data',
               data: new FormData(this),
               success: function(response) {
                  // console.log(response);
                  $('#mains').load('posts.php');
                  console.log(response);

               }
            });
         });
      </script>
      <script type="text/javascript">
         $(document).ready(function () {

            $('#mains').load('posts.php');

            $('#posts').click(function(){

                  var clickpost = $('#posts').attr('id');

                  if(clickpost == "posts")
                  {
                     $('#mains').load('posts.php');
                  };
            });

            $('#Categoriy').click(function(){
               var clickpost = $('#Categoriy').attr('id');
               if(clickpost == "Categoriy")
               {
                  $('#mains').load('category.php');
               }
            });


            $.ajax({
               url : "../Admin/restapi/category.php",
               method : "GET",
               dataType : "JSON",
               success : function (response) {
                  // console.log(response);
                  var html = '';
                  for (var i = 0; i < response.length; i++) {
                     html += '<option value="'+response[i].id+'">'+response[i].name+'</option>'
                  }
                  $('#category_id').append(html);
               }
            });
         
         });

         function logOut(){
            $.ajax({
               url: "../Admin/restapi/logOut.php",
               method: "GET",
               dataType: "JSON",
               success: function(response){
                  if (response.result == 'success') 
                  {
                     alert(response.message);
                     window.location.href = "../Admin/";
                  }
               }
            });
         }
      </script>
   </body>
</html>