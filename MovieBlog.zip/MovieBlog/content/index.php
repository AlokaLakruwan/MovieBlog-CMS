<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Movie Content</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>

        <!--navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#!">MovieBlog</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
                       
                    </ul>
                </div>
            </div>
        </nav>

        <!-- content-->
        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-8">

                    <!-- Post content-->
                    <article>
                        <!-- Post header-->
                        <header class="mb-4">
                            <!-- Post title-->
                            <div ><h1 class="fw-bolder mb-1" id="title"></h1></div>
                            <!-- Post meta content-->
                            <!-- <div class="text-muted fst-italic mb-2">Posted on September 3, 2021</div> -->
                            <!-- Post categories-->
                            <div class="cat"><a class="badge bg-secondary text-decoration-none link-light" id="name"></a></div>
                        </header>

                        <!-- Preview image-->
                        <!-- <figure class="mb-4"><img class="img-fluid rounded" src="https://www.disneyplusinformer.com/wp-content/uploads/2021/08/Shang-Chi-Character-Posters-Collage.jpg" alt="..." /></figure> -->

                        <!-- Post content-->
                        <section class="mb-5">
                            <p class="fs-5 mb-4" id="content"></p>
                            <!-- <p class="fs-5 mb-4">While you’re making plans to see the movie, in theaters everywhere today, get drawn into your own journey with T-shirts, accessories, and toys– available on shopDisney and at Disneyland Resort Backlot Premiere Shop featuring Avengers Campus at Disney California Adventure park and Super Hero Headquarters at Disney Springs. </p> -->
                        </section>

                    </article>
                </div>


                <!-- Side widget-->
                <div class="col-lg-4">

              
            
                    <div class="card mb-4"><!-- 
                        <div class="card-header">Categories</div> -->
                        <div class="card-body" id="image">

                           

                        
                        </div>
                    </div>

                </div>
            </div>
        </div>
<div id="test"></div>
        <!-- JS-->
        <script src="../js/jquery.min.js"></script>
          <script src="../js/popper.js"></script>
          <script src="../js/bootstrap.min.js"></script>
          <script src="../js/main.js"></script>
          <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
          <script src="../slick/slick.js" type="text/javascript" charset="utf-8"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" ></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/js/bootstrap.min.js"></script>
          <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
          <script src="../assets/dist/js/bootstrap.min.js"></script>

        <script type="text/javascript">


            $(document).ready(function(){
                var id = location.search.split('id=')[1];
                
                $.ajax({
                    url: "../Admin/restapi/getpost.php?id="+id,
                    method: "GET",
                    dataType: 'JSON',
                    success: function (response) {
                        console.log(response);
                           var title=response.title;
                           var content=response.content;
                            var image=response.image;
                            var categorie=response.name;
                          
                        $('#title').append(title);
                        $('#content').append(content);
                        $('#image').append(
                                ' <figure class="mb-1"><img class="img-fluid rounded" src="../Admin/uploadFiles/'+image+'"  /></figure>'

                            );
                        $('#name').append(categorie);
                    },

                }); 
            });    
            
        </script>

    </body>
</html>
