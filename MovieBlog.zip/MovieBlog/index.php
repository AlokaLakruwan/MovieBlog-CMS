<!DOCTYPE html>
<html>
   <head>
      <title>Movie Blog</title>
      <meta charset="UTF-8">
      <link rel="stylesheet" type="text/css" href="./slick/slick.css">
      <link rel="stylesheet" type="text/css" href="css/css.css">
      <link rel="stylesheet" type="text/css" href="./slick/slick-theme.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" >
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" >
      <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/carousel/">
      <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
      <link rel="stylesheet" href="css/ionicons.min.css">
      <link rel="stylesheet" href="css/flaticon.css">
      <link rel="stylesheet" href="css/style.css">
      <!-- Bootstrap core CSS -->
      <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="assets/dist/css/bootstrap.css" rel="stylesheet">
      <style>
         .bd-placeholder-img 
         {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
         }

         @media (min-width: 768px) 
         {
            .bd-placeholder-img-lg {font-size: 3.5rem;}
         }
      </style>
      <!-- Custom styles for this template -->
      <link href="css/carousel.css" rel="stylesheet">
      <style type="text/css">
         .card:hover
         {
            transform: scale(1.02);
            transition: 0.5s;
         }

         .card
         {
            background-color: #1e1e26;
            border-radius: 4%;
            margin: 3px;
            box-shadow: 5px 3px 5px black;
         }

         .size
         {
            width: 200px !important;
            height: 300px !important;
            margin:4px;
        
         }

         .size:hover
         {
            opacity: 0.4;
         }

         body
         {
            background-color: #a4152c;
         }

         h1,h3,span,p,h5
         {
            font-family: calibri;
            color: #6a6a74;
         }

         h5
         {
            font-weight: bold;
         }

         .txtstyle
         {
            color: black;
         }
         .back
         {
            background: linear-gradient(to right,white,#a4152c);
            border-left: 10px  solid #a4152c;
            padding: none;
            margin-bottom: 5px;
            margin-left: 25px;
            width: 1250px !important;
         }

         .back:hover
         {
            transform: translateX(5px);
            transition: 0.5s;
         }

         .m
         {
            margin-top: 7px;
         }

         .width
         {
         }
      </style>
      <link rel="stylesheet" type="text/css" href="css/card.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" >
   </head>
   <body>
      <div id="myCarousel" class="carousel slide mx-2" data-bs-ride="carousel">
         <ol class="carousel-indicators">
            <li data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#myCarousel" data-bs-slide-to="1"></li>
            <li data-bs-target="#myCarousel" data-bs-slide-to="2"></li>
            <li data-bs-target="#myCarousel" data-bs-slide-to="3"></li>
             <li data-bs-target="#myCarousel" data-bs-slide-to="4"></li>
              <li data-bs-target="#myCarousel" data-bs-slide-to="5"></li>
         </ol>
      
         <div class="carousel-inner">
            <div class="carousel-item active">
               
                  <img class="bd-placeholder-img" src="images/37945.jpg" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
                
               
            </div>
            <div class="carousel-item">
               <img  class="bd-placeholder-img" src="images/171325-deepika-padukone-nina-3840-x-2400.jpg" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
             
            </div>
            <div class="carousel-item">
               <img class="bd-placeholder-img"  src="images/394699-blackangel.jpg" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
             
            </div>
            <div class="carousel-item">
               <img class="bd-placeholder-img"  src="images/864637.jpg" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          
         </div>
          <div class="carousel-item">
               <img class="bd-placeholder-img"  src="images/Black-Panther-Wallpaper-13-3840-x-2400.jpg" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          
         </div>
          <div class="carousel-item">
               <img class="bd-placeholder-img"  src="images/Venom-Wallpaper-06-3840-x-2400.jpg" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
          
         </div>
         <a class="carousel-control-prev" href="#myCarousel" role="button" data-bs-slide="prev">
         <span class="carousel-control-prev-icon" aria-hidden="true"></span>
         <span class="visually-hidden">Previous</span>
         </a>
         <a class="carousel-control-next" href="#myCarousel" role="button" data-bs-slide="next">
         <span class="carousel-control-next-icon" aria-hidden="true"></span>
         <span class="visually-hidden">Next</span>
         </a>
      </div>
</div>
      <div id="row-test">
         <!-- <div>
            <div class="container-fluid back">
               <div class="row">
                  <div class="col-md-6 width" >
                     <h2 class="text-danger">Romance</h2>
                  </div>
               </div>
            </div>

            <div class="container" >
               <div class="owl-carousel owl-theme" id="cards">
                  <div class="item">
                     <div class="card">
                        <div class="box1">
                           <img class="card-img-top img-thumbnail size" src="86519706.jpg" alt="Card image cap">
                           <div class="box-content">
                              <h3 class="title">Kristiana</h3>
                           </div>
                        </div>
                        <div class="card-body">
                           <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div> -->
      </div>
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/main.js"></script>
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
      <script src="./slick/slick.js" type="text/javascript" charset="utf-8"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/js/bootstrap.min.js"></script>
      <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
      <script src="assets/dist/js/bootstrap.min.js"></script>
      <script type="text/javascript">
         $(document).ready(function(){
           
                 
           $.ajax({
              url: "Admin/restapi/getpost.php",
              method: "GET",
              dataType: 'JSON',
              success: function (response) {
                     console.log(response);
                     var html = '';
                     var html2 = '';
                     var html3 = '';

                     response.category.forEach(function(row){
                              
                        html += '<div id="'+row.name+'_'+row.id+'" data-title="'+row.name+'">';
                        html += '<div class="container-fluid back">';
                        html += '<div class="row">';
                        html += '<div class="col-md-6 width" >';
                        html += '<h2 class="text-danger">'+row.name+'</h2>';
                        html += '</div>';
                        html += '</div>';
                        html += '</div>';

                        html += '<div class="container" >';
                        html += '<div class="owl-carousel owl-theme" id="'+row.name+'">';
                        html += '</div>';
                        html += '</div>';

                        html += '</div>';

                     });
                     
                     $('#row-test').append(html);

                  response.category.forEach(function(row){
                     console.log('Cat Name : '+row.name);
                     response.post.forEach(function(row2){
                           if(row.name == row2.name){

                              console.log(row2.title);
                              var html2 = '';
                              html2 += '<div class="item">';
                              html2 += '<div class="card" onclick="parseId('+row2.post_id+')">';
                              html2 += '<div class="box1">';
                              html2 += '<img class="card-img-top img-thumbnail size" src="Admin/uploadFiles/'+row2.image+'" alt="Card image cap">';
                              html2 += '<div class="box-content">';
                              html2 += '<h3 class="title text-center">'+row2.title+'</h3>';
                              html2 += '</div>';
                              html2 += '</div>';
                             
                              html2 += '</div>';
                              html2 += '</div>';

                              $('#'+row.name).append(html2);
                           }
                    
                     });

      

                     $('#'+row.name).owlCarousel({
                        loop:true,
                        rewind: true,
                        margin:10,
                        autoplay:true,
                        autoplaySpeed:2000,
                        nav:true,
                        responsive:{
                            0:{
                                items:1
                            },
                            600:{
                                items:3
                            },
                            1000:{
                                items:5
                            }
                        }
                     });
                    
           
                  });
               },
           }); 
         });    

         function parseId(id){
             console.log(id);
             window.location.href = "content/index.php?id="+id;
         }
                 
      </script>
   </body>
</html>