-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 28, 2021 at 12:04 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `application`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(225) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `f_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `l_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `role` enum('supper_admin','admin','end_user','') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `f_name`, `l_name`, `role`, `created_date`) VALUES
(1, 'admin@gmail.com', '$2y$10$3L0Dci9BOGajgeba.ZHda.w9gQu5BWd6fna4kzhdXVNGNVbkfFiXi', 'Sasitha', 'Ruvishan', 'supper_admin', '2021-08-31 17:30:51');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Action'),
(2, 'Horror'),
(3, 'Romance'),
(4, 'Animation');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(5000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `image` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `content`, `image`, `category_id`) VALUES
(34, 'Mission Impossible 7', 'Tom Cruise\'s daredevil IMF agent has faced more than his fair share of hair-raising escapes since making his movie debut in 1996. From confronting a helicopter in the Channel Tunnel to invading the Vatican and scaling the Burj Khalifa, the world\'s tallest building, Hunt (and, by extension, Cruise) defines the word fearless.\r\n\r\nThe Mission: Impossible franchises is one of those rare ones that has improved over time. In particular, the most recent entries, Rogue Nation and Fallout, were greeted with critical acclaim and box office success. In fact, the latter movie defied all the odds to emerge as the best, and most financially successful, movie in the series so far, defying any notion of diminishing returns. Fallout pushed the envelope with its stunt work, particularly the climactic helicopter face-off that reinvested audiences in the wonder of practical effects and stunts. The scope and scale of the movie pushed it to a mighty $791 million worldwide – so where could film #7 possibly go from here?\r\n', 'mission-impossible-7.jpg', 1),
(37, 'Marvel\'s Shang-Chi', 'Can you feel the excitement in the air? Today is opening day of “Shang-Chi and The Legend of The Ten Rings.” This action-packed new film stars Simu Liu as Shang-Chi, who must confront the past he thought he left behind when he is drawn into the web of the mysterious Ten Rings organization.\r\n\r\nWhile you’re making plans to see the movie, in theaters everywhere today, get drawn into your own journey with T-shirts, accessories, and toys– available on shop Disney and at Disneyland Resort Backlot Premiere Shop featuring Avengers Campus at Disney California Adventure park and Super Hero Headquarters at Disney Springs.', 'shang-chi.jpg', 1),
(38, 'Marvel\'s Spider-Man : No Way Home', 'The first trailer has been released for “Spider-Man: No Way Home,” a continuation of a trilogy that has given us the popular superhero web-swinging around in the Marvel Cinematic Universe.\r\n\r\nThe trailer was leaked online Sunday, forcing Marvel Studios and Sony to get a high-quality version out into the world Monday, before too many eager eyes got to the pirated version.\r\n\r\nWhat’s all the fuss? Fans want to know: Just how many Spider-Men are we dealing with in this movie? After all the rumors that anyone who has either been Spider-Man or ever thought about being Spider-Man is in this movie, the anticipation for the trailer was high.', 'Spider-Man-No-Way-Home.jpg', 1),
(42, ' Maverick', 'Admittedly, many of you may not have been alive when the first movie was released (in fact, it pre-dates this writer\'s birth by one year). Nevertheless, it exerts such a reputation that most people will be familiar with certain sequences, if not necessarily the entire movie. From the infamous shirtless beach volleyball to the oft-quoted \"I feel the need for speed\" line, Top Gun is one of those movies implanted in the cerebral cortex of film fans the world over.\r\n\r\nIt was the testosterone-fuelled, American Navy-pandering, MTV-inflected blockbuster that propelled a grinning Tom Cruise to superstardom. And he reprises his role as pilot Pete \'Maverick\' Mitchell in the sequel, only this time, he\'s the one training the recruits. And director Joseph Kosinski, who worked with Cruise on 2013\'s Oblivion, says that dealing with the past is a key theme of the new movie.', 'Top-Gun-Maverick.jpg', 1),
(43, 'Afterlife', 'Set in the universe of the first two Ivan Reitman films from the 1980s, “Ghostbusters: Afterlife” tells the story of Callie, a single mom struggling to survive in Chicago with her two kids, 12-year-old Phoebe and 15-year-old Trevor. When Callie receives news of her long-estranged father’s passing – a father she never even knew – she and the kids pack up the Subaru and move to the small midwestern town of Summerville.\r\n\r\nAs the family settles into their “inheritance,” a rotting, worthless dirt farm, they soon discover that they have mysterious ties to a team of paranormal investigators called the Ghostbusters, the specter-catching team who saved New York City from supernatural destruction 35 years ago.', 'Ghostbusters-Afterlife.jpg', 1),
(44, 'Candyman', 'Director Nia DaCosta’s “Candyman” is being sold as a “spiritual sequel” to the 1992 horror classic starring Virginia Madsen and Vanessa Williams. This iteration ignores the two actual sequels to writer/director Bernard Rose’s adaptation of a Clive Barker short story, instead picking up in present day Chicago. The Cabrini Green where Madsen’s Helen Lyle character met her grisly fate is no more; the towers have been torn down and the area’s being gentrified within an inch of its life. Had Lyle survived, she’d probably be living in a place like that of artist Anthony McCoy (Yahya Abdul-Mateen II). “White people built the ghetto,” says his girlfriend, Brianna (Teyonah Parris) to her brother, Troy (Nathan Stewart-Jarrett), “and then erased it when they realized they built the ghetto.” This is not the last we’ll hear about gentrification.\r\n', 'Candyman.jpg', 2),
(45, 'A Quiet Place Part II', 'Picking up immediately after the events of the first movie, the remaining members of the Abbott family, including Evelyn (Emily Blunt), Regan (Millicent Simmonds), and Marcus (Noah Jupe) prepare to leave the destroyed farm domicile; seeking shelter nearby from the sound sensitive creatures that stalk the lands. Making their way into a steel refinery, Marcus is wounded, causing a scene that attracts some of the vicious creatures nearby, but attracts the attention of Emmett (Cillian Murphy), a former friend who’s lost everything to the invaders, and has become a very fragmented and distraught individual since. Understanding a coded radio signal and with knowledge of weaponizing sound to weaken the creatures, Regan decides to look for refuge on an island, heading into the wild on her own. \r\n', 'A Quiet Place Part II.jpg', 2),
(46, 'Don\'t Breathe 2', 'Uruguayan filmmakers Rodo Sayagues and Fede Alvarez are wise to expand on the universe of the first film, which took place entirely in and around Lang’s character’s home. The clever idea was that he was blind, and in theory an easy target for burglars. Little did they know they were dealing with a fearsome Gulf War veteran who was intimately familiar with every square foot of the place and whose other senses were heightened, making him an unstoppable killing machine. Alvarez and Sayagues co-wrote the script for the first “Don’t Breathe” with Alvarez directing; this time, they share co-writing credit with Sayagues directing.', 'Don\'t Breathe 2.jpg', 2),
(47, 'Blood Red Sky', 'Nadja (Peri Baumeister) is traveling across the Atlantic with her son Elias (Carl Anton Koch) when it’s hijacked by a group of terrorists intent on taking it down. She clearly hides a secret but Thorwarth is depressingly uninterested in holding it for long. “Blood Red Sky” should be a film that takes a sharp turn at maybe the halfway mark or possibly even later when the “bad guys” realize there’s something they didn’t plan for on the plane. Imagine this story told from the POV of the loosely-defined terrorists that then shifts to Nadja when the chaos agents realize that one of the passengers is actually a vampire.', 'Blood Red Sky.jpg', 2),
(48, 'The Conjuring: The Devil Made Me Do It', 'The Conjuring: The Devil Made Me Do It reveals a chilling story of terror, murder and unknown evil that shocked even experienced real-life paranormal investigators Ed and Lorraine Warren. One of the most sensational cases from their files, it starts with a fight for the soul of a young boy, then takes them beyond anything they’d ever seen before, to mark the first time in U.S. history that a murder suspect would claim demonic possession as a defense.', 'The Conjuring - The Devil Made Me Do It.jpg', 2),
(49, 'The Night House', 'Reeling from the unexpected death of her husband, Beth (Rebecca Hall) is left alone in the lakeside home he built for her. She tries as best she can to keep it together – but then nightmares come. Disturbing visions of a presence in the house calling to her, beckoning her with a ghostly allure. Against the advice of her friends, she begins digging into her husband’s belongings, yearning for answers. What she finds are secrets both strange and disturbing – a mystery she’s determined to unravel.', 'The Night House.jpg', 2),
(50, 'The Witcher: Nightmare of the Wolf', 'The Witcher: Nightmare Of The Wolf takes place decades before the events of The Witcher and follows the story of Vesemir (Theo James) the Witcher who trained Geralt of Rivia when he was just a wee lad.\r\n\r\nEven if you’re not into anime, you should absolutely watch Nightmare of the Wolf if you care at all about the story of the Witchers. The events of the movie will play directly into the show’s second season, not just because of Vesemir but because of the Witcher fortress of Kaer Morhen, which will be one of the more important locations in the coming season.', 'The Witcher Nightmare of the Wolf.jpg', 4),
(51, 'Vivo ', 'To be honest it is very hard to review a movie like Vivo. It is a really enjoyable family animation film. And being a musical animation, the core focus of the movie is obviously music. So if you are looking for a fun family musical then Vivo is the movie to stream.\r\n\r\nStaying true to its genre, this movie does a great job of stitching together a bunch of nice musical sequences. All the songs in the movie are very well timed that brilliantly keep the storyline forward.', 'VIVO-poster.jpg', 4),
(53, 'Space Jam: A New Legacy', 'Wait, when did everyone get a \"-verse\" to encompass all of their IP? I get it that the MCU was a way to bring together the different Marvel characters, and the Spider-verse was a way to bring the alternate universe versions of Spider-Man into one story. But around the time that the flying monkeys from \"The Wizard of Oz,\" Superman, King Kong, Agent Smith from \"The Matrix,\" and Ingrid Bergman from \"Casablanca\" show up in \"Space Jam: A New Legacy,\" a movie about basketball-playing Looney Tunes characters, we cannot help wondering whether the movie\'s not-so-side hustle is promoting every character they own that ever inspired a Funko Pop. We might also wonder whether it\'s too much of a distraction from what\'s happening in the movie as we play \"Who\'s that?\" among the hundreds of cosplaying real and virtual background figures.', 'Space Jam - A New Legacy.jpg', 4),
(54, 'Raya and the Last Dragon ', 'Walt Disney Studios have always been at the forefront of being one of the leading animation studios in children’s entertainment. Throughout the years, the studios have produced a multitude of memorable and quality made animated feature films that dazzled and spellbound generations of moviegoers. In the past decade (roughly the beginning of 2010s), Disney has seeing a resurgence of its own signature identity, with the company returning to the cartoon roots of strong-willed princesses, colorful sidekick characters, and musically charged songs. Such examples of the studio’s past definitely paid off, with a somewhat “second renaissance” with several animated features like Tangled, Frozen, and Moana being prime examples of the company’s identity. ', 'raya_poster.jpg', 4),
(55, 'PAW Patrol: The Movie ', 'When it comes to Nickelodeon\'s animated \"PAW Patrol\" series, adults generally fall into two categories. The first are intimately aware of the Canadian show because they live with small children. They know the details of its rescue puppy characters and the many, many purchasing opportunities, from stuffed animals for each of the characters and toy versions of their many vehicles to t-shirts, bed linens, birthday party decorations, backpacks, and a book to help with potty training. They laughed at Roy Kent\'s reference to \"PAW Patrol\" in the latest episode of \"Ted Lasso.\"', 'paw patrol.jpg', 4),
(63, 'The Shape of Water', 'In James Whale\'s 1935 film \"The Bride of Frankenstein,\" the monster says mournfully, \"Alone: bad. Friend: good!\" That\'s what Guillermo del Toro\'s latest film \"The Shape of Water\" is all about, the loneliness of those born before their time, born different. \"The Shape of Water\" doesn\'t cohere into the fairy tale promised by the dreamy opening. It makes its points with a jackhammer, wielding symbols in blaring neon. The mood of swooning romanticism is silly or moving, depending on your perspective. The film starts in a wavering green underwater world, with a woman floating in what looks like a drowned Atlantis. The image is otherworldly, magical, and Alexandre Desplat\'s score is wistful and bittersweet.', 'the-shape-of-water.jpg', 3),
(64, 'Fifty Shades Darker', '\r\nWho would have guessed that, when he was a boy, Christian Grey, the controlling, sexually sadistic bazillionaire at the center of E.L. James’ \"Fifty Shades of Grey\" juggernaut, was a \"Chronicles of Riddick\" fan? In a scene in \"Fifty Shades Darker,\" the sequel to \"Fifty Shades of Grey,\" Christian sits in his childhood bedroom and tentatively opens up to his girlfriend Anastasia. Looming behind his head on the wall is a gigantic \"Riddick\" poster. Did the set decorator put the poster there to add texture? Backstory? Whatever the intent, having \"Riddick\" loom as the background image in a desperately serious, post-coital conversation was inadvertently hilarious. There\'s a lot of inadvertently hilarious stuff in \"Fifty Shades Darker,\" directed by James Foley.', 'Fifty Shades Darker.jpg', 3),
(65, 'Fifty Shades Freed', 'After being proposed to, Anastasia Steele and Christian Grey finally “tie the knot”, celebrating their marriage in front of their close friends and family. The newlywed couple then sets off on their honeymoon, jet-setting to the world’s most romantic locations and enjoying the perks of being married. However, while their sexual vigor is fully charged, Ana and Christian hit some road bumps in the early days of their marriage, particularly when Ana defies Christian’s orders. While Ana must grow accustom to living the more privilege life of being Mrs. Grey, Christian must learn to live with his wife’s independence, choosing to remain as a fiction editor for a local publishing house. However, when Ana finds out she’s pregnant, it either make or break this newly minted marriage. Elsewhere, Jack Hyde, Ana’s disgruntled former boss, breaks into the offices of Christian’s company and hatches a plot between the now Mr. and Mrs. Grey to reclaim something that he believes rightfully belongs to him.\r\n', 'Fifty Shades Freed.jpg', 3),
(66, 'Fifty Shades of Grey', 'British author Erika Mitchell, known by her pen name E.L. James, has become a worldwide phenomenon. What began with a written work of Twilight fanfiction grew into the now infamous erotic romance Fifty Shades of Grey novels. Whether you like them or not, James’s novels, which have sold over a hundred million copies and translated into fifty two languages, has literally taken the world by storm, spawning an explosive interest in the ambiguous relationship of fictional characters Anastasia Steele and Christian Grey. With the novels being met with both exceedingly profitable sales and heavy criticism on the narrative’s underline orientation, Universal Pictures and Focus Features, capitalizing on its interest, have taken up the mantle on adapting James’s first novel with the movie Fifty Shades of Grey. Is this movie worth a glance or is it simply too erotic for the cinematic world?\r\n', 'fifty-shades-of-gray.png', 3),
(67, 'Below Her Mouth', 'Construction worker Dallas (Erika Linder, who is famous, apparently, as an androgynous supermodel) is definitely a lesbian. Fashion editor Jasmine (Natalie Krill) is trying to be straight, or something; she’s engaged to Rile (Sebastian Pigott), which isn’t even a name but which certainly describes she does to him when she has a weekend fling with Dallas while he is off on a business trip. “Try to take some time for yourself this weekend,” her fiancé tells her over the phone, so she cheats on him. With a woman.', 'Below Her Mouth.jpg', 3),
(68, 'The Firefly', 'Written and directed by Ana Maria Hermida, The Firefly beautifully explores the different ways in which the human body copes with the grieving process. Beginning with a scene in which Lucia decides to end her marriage, the story then flashbacks to the set of circumstances that led her to make this decision. After the tragic sudden loss of her estranged brother Andre, Lucia and his bride Mariana meet accidentally. Due to an unsupportive husband, Lucia is drawn towards Mariana, as she needs more care than Lucia does. Through their shared memories of Andre, the two women find comfort in each other in a way that they couldn’t have anticipated.', 'la-luciernaga-the-firefly.jpg\r\n', 3),
(71, 'Luca', 'Luca, however, feels like a good fit for what used to be direct-to-video. Historically, Pixar has gone the other way; back in the late ‘90s, Toy Story 2 was gonna be a “Return of Jafar” style priced-to-own affair until Pixar realized what they had on their hands. Luca, by comparison, puts me in mind of 2015’s The Good Dinosaur (and, looking at the release slate, almost everything after): the rare (but not as much as they used to be) underwhelming Pixar offering.', 'Luca.jpg', 4),
(73, 'Extraction-2', 'Netflix’s original action movie Extraction released on 24 April and garnered positive reviews from critics. The hardcore action movie received a huge response from fans. Extraction showcases Chris Hemsworth as a mercenary Tyler Rake recruited for a dangerous mission to rescue the son of India’s biggest drug lord from Bangladesh’s biggest drug lord. While the fans are still enjoying Extraction on Netflix, Extraction 2 is reportedly already in the works.\r\n\r\nThe ending of Extraction is deliberately left ambiguous. We see Tyler fall off the bridge and into the river after being shot in the neck. In the final scene, we see someone watching Ovi (Rudhraksh Jaiswal). Was it Tyler or just an illusion of Ovi’s imagination? The ending has made a way for a sequel. Will there be Extraction 2? Here’s what we know so far.', 'extraction-2.jpg', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
