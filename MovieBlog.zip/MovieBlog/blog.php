<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Blog Post</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>

        <!--navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#!">Movie Blog</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#">Blog</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- content-->
        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-8">

                    <!-- Post content-->
                    <article>
                        <!-- Post header-->
                        <header class="mb-4">
                            <!-- Post title-->
                            <h1 class="fw-bolder mb-1">Marvel's Shang-Chi Relesed to Theater</h1>
                            <!-- Post meta content-->
                            <div class="text-muted fst-italic mb-2">Posted on September 3, 2021</div>
                            <!-- Post categories-->
                            <a class="badge bg-secondary text-decoration-none link-light" href="#!">Action</a>
                        </header>

                        <!-- Preview image-->
                        <figure class="mb-4"><img class="img-fluid rounded" src="https://www.disneyplusinformer.com/wp-content/uploads/2021/08/Shang-Chi-Character-Posters-Collage.jpg" alt="..." /></figure>

                        <!-- Post content-->
                        <section class="mb-5">
                            <p class="fs-5 mb-4">Can you feel the excitement in the air? Today is opening day of “Shang-Chi and The Legend of The Ten Rings.” This action-packed new film stars Simu Liu as Shang-Chi, who must confront the past he thought he left behind when he is drawn into the web of the mysterious Ten Rings organization.</p>
                            <p class="fs-5 mb-4">While you’re making plans to see the movie, in theaters everywhere today, get drawn into your own journey with T-shirts, accessories, and toys– available on shopDisney and at Disneyland Resort Backlot Premiere Shop featuring Avengers Campus at Disney California Adventure park and Super Hero Headquarters at Disney Springs. </p>
                        </section>

                    </article>
                </div>

                <!-- Side widget-->
                <div class="col-lg-4">

                    <!-- Search-->
                    <div class="card mb-4">
                        <div class="card-header">Search</div>
                        <div class="card-body">
                            <div class="input-group">
                                <input class="form-control" type="text" placeholder="Enter Movie Name" aria-label="Enter search term..." aria-describedby="button-search" />
                                <button class="btn btn-primary" id="button-search" type="button">Search!</button>
                            </div>
                        </div>
                    </div>

                    <!-- Categories-->
                    <div class="card mb-4">
                        <div class="card-header">Categories</div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <ul class="list-unstyled mb-0">
                                        <li><a href="#!">Action</a></li>
                                        <li><a href="#!">Horror</a></li>
                                    </ul>
                                </div>
                                <div class="col-sm-6">
                                    <ul class="list-unstyled mb-0">
                                        <li><a href="#!">Romance</a></li>
                                        <li><a href="#!">Animation</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
<div id="title"></div>
        <!-- JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
        <script src="js/scripts.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){


            $.ajax({
                url: "../MovieBlog/Admin/restapi/post.php",
                method: "GET",
                dataType: 'JSON',
                cache: false,
                success: function (response) {
                       console.log(response);

                  
              response(function(row){
                     $('#title').append(
                        row.title

                     
                       );

                       });
                                 
              },

               
                error: function(response) {
   alert(response);
                }
            });
            });
        </script>
    </body>
</html>
